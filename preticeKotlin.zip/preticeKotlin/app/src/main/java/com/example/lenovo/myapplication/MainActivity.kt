package com.example.lenovo.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.Chronometer
import java.util.ArrayList

class MainActivity : AppCompatActivity() {
    private val fruitList = ArrayList<Fruit>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var chronometer: Chronometer = findViewById(R.id.chronometer) as Chronometer
        var startTime = SystemClock.elapsedRealtime()
        chronometer.setBase(startTime)
        chronometer.start()

        initFruits()
        val recyclerView = findViewById(R.id.recycler_view) as RecyclerView
        val layoutManager = GridLayoutManager (this,4)
        //layoutManager.orientation = LinearLayoutManager.HORIZONTAL
        recyclerView.layoutManager = layoutManager
        val adapter = FruitAdapter(fruitList)
        recyclerView.adapter = adapter
    }

    private fun initFruits() {
        for (i in 0..1) {
            val apple = Fruit("Apple", R.drawable.apple_pic)
            fruitList.add(apple)
            val banana = Fruit("Banana", R.drawable.banana_pic)
            fruitList.add(banana)
            val orange = Fruit("Orange", R.drawable.orange_pic)
            fruitList.add(orange)
        }
    }

}
