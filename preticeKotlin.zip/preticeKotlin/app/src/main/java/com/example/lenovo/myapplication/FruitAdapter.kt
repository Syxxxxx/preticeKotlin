package com.example.lenovo.myapplication

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class FruitAdapter(private val mFruitList: List<Fruit>) : RecyclerView.Adapter<FruitAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var fruitView: View
        var fruitImage: ImageView
        var fruitName: TextView

        init {
            fruitView = view
            fruitImage = view.findViewById(R.id.fruit_image) as ImageView
            fruitName = view.findViewById(R.id.fruitname) as TextView
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.fruit_item, parent, false)
        val holder = ViewHolder(view)
        holder.fruitView.setOnClickListener(View.OnClickListener {
            var position = holder.adapterPosition
            var fruit = mFruitList.get(position)
            Toast.makeText(view.context,"you clicked view"+fruit.name,Toast.LENGTH_SHORT).show()
        })
        holder.fruitImage.setOnClickListener(View.OnClickListener {
            var position = holder.adapterPosition
            var fruit = mFruitList.get(position)
            Toast.makeText(view.context,"you clicked image"+ fruit.name,Toast.LENGTH_SHORT).show()
        })
        return holder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val fruit = mFruitList[position]
        holder.fruitImage.setImageResource(fruit.imageId)
        holder.fruitName.text = fruit.name
    }

    override fun getItemCount(): Int {
        return mFruitList.size
    }
}
