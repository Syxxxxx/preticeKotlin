package com.example.lenovo.myapplication;

import android.arch.lifecycle.ViewModel;

public class ChronometerViewModel extends ViewModel {

}
