package com.example.lenovo.myapplication

class Fruit(val name: String, val imageId: Int)